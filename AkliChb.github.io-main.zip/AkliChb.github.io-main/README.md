Ce dépôt contient un site web simple et pédagogique consacré à la sécurité informatique.
Il présente les principales menaces en ligne, les méthodes de protection et plusieurs outils utiles.
Le site a été réalisé dans le cadre d’un projet universitaire par Walid Knatef et Chabane Akli (L2 Informatique).
Il est entièrement développé en HTML/CSS et hébergé via GitHub Pages.
